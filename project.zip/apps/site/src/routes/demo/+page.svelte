<script lang="ts">
	import { resolve } from '$app/paths';
</script>

<a href={resolve('/demo/paraglide')}>paraglide</a>
